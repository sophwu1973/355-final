**Submitted by**: Sophia Wu (directory id: swu1973)  
**Group Members**: Sophia Wu (swu1973)  
**App Description**: Users can find their location on Google Maps based off their IP Address.  
**YouTube Video Link**: https://youtu.be/7-XdSS3ApVw
**Deployment**:  
**APIs**: IP API(https://ip-api.com/)  
**Contact Email**: swu1973@terpmail.umd.edu